package com.example.permissionsdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int CAM_CODE = 100;
    private static final int EXTERNAL_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button chCamBtn = findViewById(R.id.checkCamPerm);
        Button gtCamBtn = findViewById(R.id.grantCamPerm);
        Button chExtBtn = findViewById(R.id.checkExternalPerm);
        Button gtExtBtn = findViewById(R.id.grantExternalPerm);


        chCamBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermission(Manifest.permission.CAMERA,CAM_CODE);
            }
        });

        gtCamBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               grantPermission(Manifest.permission.CAMERA,CAM_CODE);
            }
        });

        chExtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE,EXTERNAL_CODE);
            }
        });

        gtExtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                grantPermission(Manifest.permission.READ_EXTERNAL_STORAGE,EXTERNAL_CODE);
            }
        });
    }

    public void checkPermission(String permission,int requestCode){
        if(ContextCompat.checkSelfPermission(MainActivity.this,permission) == PackageManager.PERMISSION_DENIED){
            if(requestCode == CAM_CODE){
                Toast.makeText(getApplicationContext(),"Camera Permission is Denied",Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(),"External Storage Read Permission is Denied",Toast.LENGTH_LONG).show();
            }

        }else{
            if(requestCode == CAM_CODE){
                Toast.makeText(getApplicationContext(),"Camera Permission is already granted to you",Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(),"External Storage Read Permission is already granted to you",Toast.LENGTH_LONG).show();
            }

        }
    }

    public void grantPermission(String permission, int requestCode){
        if(ContextCompat.checkSelfPermission(MainActivity.this,permission) == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{permission},requestCode);
        }else{
            if(requestCode == CAM_CODE){
                Toast.makeText(getApplicationContext(),"Camera Permission is already granted to you",Toast.LENGTH_LONG).show();
            }else {
                Toast.makeText(getApplicationContext(), "External Storage Read Permission is already granted to you", Toast.LENGTH_LONG).show();
            }
        }
    }
}